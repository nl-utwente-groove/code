/**
 * $Id: mxMouseAdapter.java,v 1.1 2010-06-01 10:18:45 gaudenz Exp $
 * Copyright (c) 2008, Gaudenz Alder
 */
package com.mxgraph.swing.util;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/**
 *
 */
public class mxMouseAdapter implements MouseMotionListener, MouseListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6413162217897819199L;

	/**
	 * 
	 */
	public void mouseDragged(MouseEvent e)
	{
		// empty
	}

	/**
	 * 
	 */
	public void mousePressed(MouseEvent e)
	{
		// empty
	}

	/**
	 * 
	 */
	public void mouseReleased(MouseEvent e)
	{
		// empty
	}

	/**
	 * 
	 */
	public void mouseMoved(MouseEvent e)
	{
		// empty
	}

	/**
	 * 
	 */
	public void mouseClicked(MouseEvent e)
	{
		// empty
	}

	/**
	 * 
	 */
	public void mouseEntered(MouseEvent e)
	{
		// empty
	}

	/**
	 * 
	 */
	public void mouseExited(MouseEvent e)
	{
		// empty
	}

}
