@SuppressWarnings("all")
interface Interfaces {
	enum Ranks {
		CLUBS,
		HEARTS,
		DIAMONDS,
		SPADES;
	}
	int x = 10;
	void y();
	int a = 20;
	void b();
}
