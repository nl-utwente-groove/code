class WithInnerAnnotation {
	@interface Inner {
		int bar() default 42;
	}
}