class ToStringConfiguration {
	int x;
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	public java.lang.String toString() {
		return "ToStringConfiguration(" + this.x + ")";
	}
	@java.lang.SuppressWarnings("all")
	public int getX() {
		return this.x;
	}
}
class ToStringConfiguration2 {
	int x;
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	public java.lang.String toString() {
		return "ToStringConfiguration2(x=" + this.x + ")";
	}
}
class ToStringConfiguration3 {
	int x;
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	public java.lang.String toString() {
		return "ToStringConfiguration3(" + this.getX() + ")";
	}
	@java.lang.SuppressWarnings("all")
	public int getX() {
		return this.x;
	}
}