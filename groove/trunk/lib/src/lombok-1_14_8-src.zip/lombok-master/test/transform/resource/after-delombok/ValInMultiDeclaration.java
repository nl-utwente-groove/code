public class ValInMultiDeclaration {
	public void test() {
		final int x = 10;
		final java.lang.String y = "";
	}
}