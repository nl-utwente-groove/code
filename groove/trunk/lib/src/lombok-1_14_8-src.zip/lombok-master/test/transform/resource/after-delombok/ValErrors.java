public class ValErrors {
	public void unresolvableExpression() {
		final java.lang.Object c = d;
	}
	public void arrayInitializer() {
		val e = {"foo", "bar"};
	}
}