class Getter {
	static boolean foo;
	static int bar;
	@java.lang.SuppressWarnings("all")
	public static boolean isFoo() {
		return Getter.foo;
	}
	@java.lang.SuppressWarnings("all")
	public static int getBar() {
		return Getter.bar;
	}
}
