class Setter {
	static boolean foo;
	static int bar;
	@java.lang.SuppressWarnings("all")
	public static void setFoo(final boolean foo) {
		Setter.foo = foo;
	}
	@java.lang.SuppressWarnings("all")
	public static void setBar(final int bar) {
		Setter.bar = bar;
	}
}
