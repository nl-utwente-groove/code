class GetFoo {
	private int foo;
	@java.lang.SuppressWarnings("all")
	public int getFoo() {
		return this.foo;
	}
}
