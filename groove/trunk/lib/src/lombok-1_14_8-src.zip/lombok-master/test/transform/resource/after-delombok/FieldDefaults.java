class FieldDefaults1 {
	final int x;
	int y;
	FieldDefaults1(int x) {
		this.x = x;
	}
}
class FieldDefaults2 {
	int x;
	private int y;
}