class PlaceFillerToMakeSurePositionIsRelevant {
}
class GetterOnMethodErrors {
	private int test;
	@java.lang.SuppressWarnings("all")
	public int getTest() {
		return this.test;
	}
}