import lombok.experimental.*;
final class ValueExperimentalStarImport {
	@java.lang.SuppressWarnings("all")
	public ValueExperimentalStarImport() {
		
	}
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	public boolean equals(final java.lang.Object o) {
		if (o == this) return true;
		if (!(o instanceof ValueExperimentalStarImport)) return false;
		return true;
	}
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	public int hashCode() {
		int result = 1;
		return result;
	}
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	public java.lang.String toString() {
		return "ValueExperimentalStarImport()";
	}
}