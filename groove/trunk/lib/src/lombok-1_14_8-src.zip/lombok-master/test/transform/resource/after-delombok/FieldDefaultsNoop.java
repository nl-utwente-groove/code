class FieldDefaultsNoop {
}