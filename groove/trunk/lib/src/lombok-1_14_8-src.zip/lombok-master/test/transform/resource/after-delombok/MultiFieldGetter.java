class MultiFieldGetter {
	int x;
	int y;
	@java.lang.SuppressWarnings("all")
	protected int getX() {
		return this.x;
	}
	@java.lang.SuppressWarnings("all")
	protected int getY() {
		return this.y;
	}
}
class MultiFieldGetter2 {
	int x;
	int y;
	@java.lang.SuppressWarnings("all")
	int getX() {
		return this.x;
	}
	@java.lang.SuppressWarnings("all")
	int getY() {
		return this.y;
	}
}