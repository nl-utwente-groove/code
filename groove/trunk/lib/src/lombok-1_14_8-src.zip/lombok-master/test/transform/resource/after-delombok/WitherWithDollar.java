class WitherWithDollar {
	int $i;
}
