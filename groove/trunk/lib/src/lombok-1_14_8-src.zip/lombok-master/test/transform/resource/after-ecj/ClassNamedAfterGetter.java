class GetFoo {
  private @lombok.Getter int foo;
  GetFoo() {
    super();
  }
  public @java.lang.SuppressWarnings("all") int getFoo() {
    return this.foo;
  }
}
