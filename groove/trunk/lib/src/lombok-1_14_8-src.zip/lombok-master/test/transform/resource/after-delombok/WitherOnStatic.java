class WitherOnStatic {
	static boolean foo;
	static int bar;
}
