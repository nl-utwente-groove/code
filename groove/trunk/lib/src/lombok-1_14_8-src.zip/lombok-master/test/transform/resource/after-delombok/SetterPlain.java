class SetterPlain {
	int i;
	int foo;
	@java.lang.SuppressWarnings("all")
	public void setI(final int i) {
		this.i = i;
	}
	@java.lang.SuppressWarnings("all")
	public void setFoo(final int foo) {
		this.foo = foo;
	}
}