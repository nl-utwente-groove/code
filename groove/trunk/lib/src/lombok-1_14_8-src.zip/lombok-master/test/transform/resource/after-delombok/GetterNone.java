class GetterNone {
	int i;
	int foo;
	@java.lang.SuppressWarnings("all")
	public int getI() {
		return this.i;
	}
}