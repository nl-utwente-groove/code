import lombok.*;
class DoNothingDueToTopLevel {
	void test() {
		val x = null;
	}
}
class val {
}
