package com.sun.tools.javac.parser;

import com.sun.tools.javac.tree.JCTree;

public class JavacParser {
	protected JavacParser(ParserFactory fac, Lexer S, boolean keepDocComments, boolean keepLineMap, boolean keepEndPositions) {
	}
	
	public JCTree.JCCompilationUnit parseCompilationUnit() {
		return null;
	}
}
