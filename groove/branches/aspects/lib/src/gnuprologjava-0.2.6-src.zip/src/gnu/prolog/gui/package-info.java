/**
 * @deprecated
 */
package gnu.prolog.gui;

