/**
 * This package contains demo programs which show how to use the gnu.prolog library
 */
package gnu.prolog.demo;

